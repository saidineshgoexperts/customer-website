'use client';

import { PremiumHomePage } from '@/components/pghostels/PremiumHomePage';

export default function PGHostelsPage() {
    return <PremiumHomePage />;
}
