import { DetailsPage } from '@/components/spasalon/DetailsPage';

export default function SpaSalonDetailPage() {
    return <DetailsPage />;
}
