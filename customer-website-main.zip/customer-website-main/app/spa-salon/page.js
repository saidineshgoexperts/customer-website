import { HomePage } from '@/components/spasalon/HomePage';

export default function SpaSalonPage() {
    return <HomePage />;
}
