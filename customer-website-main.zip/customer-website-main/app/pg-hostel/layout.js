export const metadata = {
    title: 'PG & Hostels Booking | SuperHub',
    description: 'Find verified PGs, co-living spaces, and hostels near your college or office.',
};

export default function PGHostelLayout({ children }) {
    return children;
}
